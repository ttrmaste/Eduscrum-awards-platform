import axios from "axios"

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
})

// lê token do storage
function getToken() {
  return localStorage.getItem("auth_token")
}

// injeta o Bearer token em cada pedido
api.interceptors.request.use((config) => {
  const token = getToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export default api
