package com.eduscrum.awards.model;

public enum PapelSistema {
    PROFESSOR,
    ALUNO,
    ADMIN
}
