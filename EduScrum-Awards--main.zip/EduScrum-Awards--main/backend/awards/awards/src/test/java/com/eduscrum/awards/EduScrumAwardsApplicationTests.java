package com.eduscrum.awards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduScrumAwardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
